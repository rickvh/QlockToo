#include <stdint.h>        /* For uint8_t definition */
/* 
 * File:   eeprom.h
 * Author: Rick
 *
 * Created on 15 mei 2013, 22:33
 */

#ifndef EEPROM_H
#define	EEPROM_H

#define BRIGHTNESS_MANUAL   0
#define BRIGHTNESS_AUTO     1
#define ENERGYSAVE_OFF      0
#define ENERGYSAVE_TIME     1
#define ENERGYSAVE_LDR      2

struct settings{
    uint8_t brightness;
    uint8_t brightnessMode;
    uint8_t energysaveMode;
    uint8_t cornerMode;
};

struct settings loadSettings();

void saveSettings(struct settings);

#endif	/* EEPROM_H */

