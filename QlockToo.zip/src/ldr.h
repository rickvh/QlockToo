/* 
 * File:   ldr.h
 * Author: Rick
 *
 * Created on 18 april 2013, 22:42
 */

#ifndef LDR_H
#define	LDR_H

unsigned char ldr_read();

#endif	/* LDR_H */

