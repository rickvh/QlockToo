#include <xc.h>
#include <plib/i2c.h>
#include "rtc.h"

// DS1307 address: 1101000 = 0xD0
#define DS1307_ADDRESS_READ     0xD1
#define DS1307_ADDRESS_WRITE    0xD0

unsigned char hours, minutes, seconds;

void rtcSetSeconds(unsigned char seconds)
{
}

void rtcSetMinutes(unsigned char minutes)
{
}
void rtcSetHours(unsigned char hours)
{
}

unsigned char rtcGetSeconds(void)
{
    return seconds;
}

unsigned char rtcGetMinutes(void)
{
    return minutes;
}

unsigned char rtcGetHours(void)
{
    return hours;
}


// schrijf seconden
void InitRtc(void)
{
    StartI2C(); // begin I2C communication
    IdleI2C();
    WriteI2C( DS1307_ADDRESS_WRITE );
    IdleI2C();
    WriteI2C( 0x00 ); // register: seconds
    IdleI2C();
    WriteI2C( 0x00 ); // 0sec + enable clock
    IdleI2C();
    StopI2C();


    // TODO: alleen de klok 'aanzetten' indien deze nog niet loopt
    // init: SQWE @1Hz
    StartI2C(); // begin I2C communication
    IdleI2C();
    WriteI2C( DS1307_ADDRESS_WRITE );
    IdleI2C();
    WriteI2C( 0x07 ); // register: control register
    IdleI2C();
    WriteI2C( 0x10 ); // SQWE @1Hz
    IdleI2C();
    StopI2C();
}


void ReadRtc()
{
    // Lees alles
    StartI2C(); // begin I2C communication
    IdleI2C();
    WriteI2C( DS1307_ADDRESS_WRITE );
    IdleI2C();
    WriteI2C( 0x00 ); // address to read
    IdleI2C();
    RestartI2C(); // Initiate a RESTART command
    IdleI2C();
    WriteI2C( DS1307_ADDRESS_READ );
    IdleI2C();
    seconds = ReadI2C();
    IdleI2C();
    AckI2C();
    IdleI2C();
    minutes = ReadI2C();
    IdleI2C();
    AckI2C();
    IdleI2C();
    hours = ReadI2C();
    IdleI2C();
    NotAckI2C();
    IdleI2C();
    StopI2C();

    // convert BCD-format to decimal and eliminate non-time data
    seconds = (((seconds & 0x70) >> 4)*10+(seconds & 0x0F));
    minutes = ((minutes >> 4)*10+(minutes & 0x0F));
    hours = (((hours & 0x30) >> 4)*10+(hours & 0x0F));
}