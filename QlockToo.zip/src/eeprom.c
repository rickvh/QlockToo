#include "eeprom.h"
#include <stdint.h>        /* For uint8_t definition */

struct settings loadSettings()
{
    struct settings ff;
    return ff;
}

void saveSettings(struct settings)
{
    // TODO
}