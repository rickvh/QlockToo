#include <xc.h>             /* XC8 General Include File */

#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */
#include <stdio.h>
#include <string.h>

#include "configuration.h"
#include "system.h"        /* System funct/params, like osc/peripheral config */
#include <delays.h>
#include <plib/i2c.h>
#include "sw_uart.h"       /* Software UART */
#include "rtc.h"
#include "eeprom.h"
#include "user.h"          /* User funct/params, such as InitApp */
#include "leddriver.h"
#include "ldr.h"
#include "buttons.h"
#include "characters.h"

#define MODE_CLOCK              0
#define MODE_SECONDS            1
#define MODE_BRIGHTNESS         2
#define MODE_OFF                3
#define MODE_TIME_SET_HOURS     4
#define MODE_TIME_SET_MINS      5
#define MODE_BRIGHTNESS_MODE    6
#define MODE_CORNER_MODE        7
#define MODE_LEDTEST            8
#define MODE_ANIMATION_1        9
#define MODE_ANIMATION_2        10
#define MODE_ANIMATION_3        11
#define MODE_ALL                12


/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/
uint8_t message[60];
uint8_t current_mode, current_char;
bool rtc_updated, settings_updated;
uint16_t i,j, tmp_uur, tmp_min;//just a simple counter
uint8_t time_sec, time_min, time_hour;
uint16_t temprow, currentrow;
struct settings settings;

#ifdef DEBUG
    bool uart_enabled;
#endif

/*
 * Functions
 */
int ReadLedData();


/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/

void main(void)
{
    i=0;
//    uint8_t c;

    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize I/O and Peripherals for application */
    InitQlockToo();
    //StartI2C();
    loadSettings();
    // TODO
    /*if (rtc_not_running)
    {
        InitRtc();
    }*/
    //RestartI2C();
    leddriver_init();

//    current_mode = MODE_LEDTEST;

#ifdef DEBUG
    /* startup delay */
    i = 1000;
    while(i--)
    {
        __delay_ms(10);
    }

    uart_enabled = 1;
    sprintf(message,"Init done\r\n");
    DEBUG_PRINTLN(message);

    while (uart_enabled)
    {
        while(i<100)
        {
            i++;
            __delay_ms(10);
        }

        c = ReadUART();

        // command dispatcher
        switch (c)
        {
            case 0x02: // year, rtc set year
                break;
            case 0x04: // rtc set month
                break;
            case 0x06: // rtc set day
                break;
            case 0x08: // rtc set hour
                break;
            case 0x0A: // rtc set minute
                break;
            case 0x0C: // rtc set sec
                break;
            case 0x12: // rtc get year
                break;
            case 0x14: // rtc get month
                break;
            case 0x16: // rtc get day
                break;
            case 0x18: // rtc get hour
                ReadRtc();
                time_hour = rtcGetHours();
                sprintf(message,"Hour: %d\r\n", time_hour);
                break;
            case 0x1A: // rtc get minute
                ReadRtc();
                time_min = rtcGetMinutes();
                sprintf(message,"Minutes: %d\r\n", time_min);
                break;
            case 0x1C: // rtc get sec
                ReadRtc();
                time_sec = rtcGetSeconds();
                sprintf(message,"Seconds: %d\r\n", time_sec);
                break;
            case 0x20: // read LDR
                sprintf(message,"LDR: 0x%02X\r\n", ldr_read());
                break;
            case 0x30: // read button 1
                sprintf(message,"Button 1: error\r\n");
                break;
            case 0x32: // read button 2
                sprintf(message,"button 2: error\r\n");
                break;
            case 0x41: // write screenbuffer, row 1
                leddriver_screenbuffer[0] = ReadLedData();
                sprintf(message,"Row 1 set\r\n");
                break;
            case 0x42: // write screenbuffer, row 2
                leddriver_screenbuffer[1] = ReadLedData();
                sprintf(message,"Row 2 set\r\n");
                break;
            case 0x43: // write screenbuffer, row 3
                leddriver_screenbuffer[2] = ReadLedData();
                sprintf(message,"Row 3 set\r\n");
                break;
            case 0x44: // write screenbuffer, row 4
                leddriver_screenbuffer[3] = ReadLedData();
                sprintf(message,"Row 4 set\r\n");
                break;
            case 0x45: // write screenbuffer, row 5
                leddriver_screenbuffer[4] = ReadLedData();
                sprintf(message,"Row 5 set\r\n");
                break;
            case 0x46: // write screenbuffer, row 6
                leddriver_screenbuffer[5] = ReadLedData();
                sprintf(message,"Row 6 set\r\n");
                break;
            case 0x47: // write screenbuffer, row 7
                leddriver_screenbuffer[6] = ReadLedData();
                sprintf(message,"Row 7 set\r\n");
                break;
            case 0x48: // write screenbuffer, row 8
                leddriver_screenbuffer[7] = ReadLedData();
                sprintf(message,"Row 8 set\r\n");
                break;
            case 0x49: // write screenbuffer, row 9
                leddriver_screenbuffer[8] = ReadLedData();
                sprintf(message,"Row 9 set\r\n");
                break;
            case 0x4A: // write screenbuffer, row 10
                leddriver_screenbuffer[9] = ReadLedData();
                sprintf(message,"Row 10 set\r\n");
                break;
            case 0x4B: // write screenbuffer, row 11
                leddriver_screenbuffer[10] = ReadLedData();
                sprintf(message,"Row 11 set\r\n");
                break;
            case 0x4F: // enable LED-display
                leddriver_init();
                sprintf(message,"LED-driver initialized\r\n");
                break;
            case 0x50: // enable interrupts
                INT2IE = 1;
                T0IE = 1;
                GIE = 1;
                sprintf(message,"Interrupts enabled\r\n");
                break;
            case 0x52: // disable interrupts
                GIE = 0;
                INT0E = 0;
                T0IE = 0;
                sprintf(message,"Interrupts disabled\r\n");
                break;
            case 0x60: // start main loop
                uart_enabled = 0;
                sprintf(message,"Start main loop\r\n");
                T0CON = 0xC2;   // Timer0 enabled: 8-bit, internal clock, prescaler 1:8
                break;
            case 0x70:
                leddriver_setMinutes(tmp_uur++, tmp_min++);

                if (tmp_min > 59)
                    tmp_min = 0;

                if (tmp_uur > 23)
                    tmp_uur = 0;
                break;
            default:
                sprintf(message,"Unknown command\r\n");
        }
        DEBUG_PRINTLN(message);
    }
#else
    INT2IE = 1;
    T0IE = 1;
    GIE = 1;
#endif

    // main loop
    while(1)
    {
#ifdef DEBUG
        i = 1000;
        while(i--)
        {
            __delay_ms(10);
        }
        updateButtonReadings();
#endif
        // MODE
        if (button1Pressed())
        {
            leddriver_clear();
            if (settings_updated)
            {
                saveSettings(settings);
                settings_updated = false;
            }
            current_mode++;
            if (current_mode > MODE_ALL)
                current_mode = 0;

#ifdef DEBUG
            sprintf(message,"Selected mode: %d\r\n", current_mode);
            DEBUG_PRINTLN(message);
#endif
        }

        // +
        if(button2Pressed())
        {
            switch(current_mode)
            {
                case MODE_BRIGHTNESS:
                    if (++settings.brightness == 10)
                        settings.brightness = 0;
                    break;
                case MODE_BRIGHTNESS_MODE:
                    settings.brightnessMode = !settings.brightnessMode;
                    break;
                case MODE_CORNER_MODE:
                    settings.cornerMode = !settings.cornerMode;
                    break;
                case MODE_TIME_SET_HOURS:
                    if (++time_hour == 24)
                        time_hour = 0;
                    rtcSetHours(time_hour);
                    break;
                case MODE_TIME_SET_MINS:
                    if (++time_min == 60)
                        time_min = 0;
                    rtcSetMinutes(time_min);
                    rtcSetSeconds(0);
                    break;
            }
        }

        if (rtc_updated)
        {
#ifdef DEBUG
            sprintf(message,"RTC uitlezen\r\n");
            DEBUG_PRINTLN(message);
#endif
            ReadRtc();
            time_hour = rtcGetHours();
            time_min = rtcGetMinutes();
            time_sec = rtcGetSeconds();
            rtc_updated = 0;
        }

        i = 5;
        while(i--)
        {
            __delay_ms(10);
        }

        switch(current_mode)
        {
            case MODE_CLOCK:
                leddriver_clear();
                leddriver_setMinutes(time_hour, time_min);
                leddriver_setCorners(time_min);
                break;
            case MODE_SECONDS:
                leddriver_clear();
                for (i = 0; i < 7; i++) {
                    leddriver_screenbuffer[1 + i] |= numbers[time_sec/10][i] << 11;
                    leddriver_screenbuffer[1 + i] |= numbers[time_sec%10][i] << 5;
                }
                break;
            case MODE_BRIGHTNESS:
                leddriver_clear();
                for (i = 0; i < 7; i++) {
                    leddriver_screenbuffer[1 + i] |= symbols[0][i] << 11;
                    leddriver_screenbuffer[1 + i] |= numbers[settings.brightness][i] << 5;
                }
                break;
            case MODE_OFF:
                break;
            case MODE_TIME_SET_HOURS:
                for (i = 0; i < 4; i++) {
                    leddriver_screenbuffer[i] |= letters['H' - 'A'][i] << 9;
                    leddriver_screenbuffer[i + 5] |= numbers[time_hour/10][i] << 11;
                    leddriver_screenbuffer[i + 5] |= letters[time_hour%10][i] << 5;
                }
                break;
            case MODE_TIME_SET_MINS:
                for (i = 0; i < 4; i++) {
                    leddriver_screenbuffer[i] |= letters['M' - 'A'][i] << 9;
                    leddriver_screenbuffer[i + 5] |= numbers[time_min/10][i] << 11;
                    leddriver_screenbuffer[i + 5] |= letters[time_min%10][i] << 5;
                }
                break;
            case MODE_BRIGHTNESS_MODE:
                leddriver_clear();
                for (i = 0; i < 7; i++) {
                    leddriver_screenbuffer[1 + i] |= symbols[0][i] << 11;
                    if (settings.brightnessMode == BRIGHTNESS_AUTO)
                        leddriver_screenbuffer[1 + i] |= letters['A' - 'A'][i] << 5;
                    else
                        leddriver_screenbuffer[1 + i] |= letters['M' - 'A'][i] << 5;
                }
                break;
            case MODE_CORNER_MODE:
                leddriver_screenbuffer[0] = 0x0400;
                break;
            case MODE_LEDTEST:
                temprow = temprow >> 1;
                if (temprow < 0x0020)
                {
                    temprow = 0x8000;
                    currentrow++;
                    if (currentrow > 9)
                    {
                        currentrow = 0;
                    }
                }
                leddriver_clear();
                leddriver_screenbuffer[currentrow] = temprow;
                break;
            case MODE_ANIMATION_1:
                leddriver_clear();
                for (i=0; i<11; i++)
                {
                    leddriver_screenbuffer[i] = TMR1H;
                    leddriver_screenbuffer[i] = leddriver_screenbuffer[i] << 8;
                    leddriver_screenbuffer[i] |= TMR1L;
                    __delay_ms(1);
                }
                break;
            case MODE_ANIMATION_2:
                leddriver_screenbuffer[0] = 0x0200;
                break;
            case MODE_ANIMATION_3:
                leddriver_screenbuffer[0] = 0x0100;
                break;
            case MODE_ALL:
                for (i=0; i<11; i++)
                {
                    leddriver_screenbuffer[i] = 0xFFFF;
                }
                break;
            default:
                break;
        }
    }
}


int ReadLedData()
{
    uint16_t temp = ReadUART();
    temp = temp << 8;
    temp = temp | ReadUART();
    return temp;
}


/******************************************************************************/
/* Interrupt handler                                                          */
/******************************************************************************/
void interrupt isr(void)
{
    static unsigned char debounce_timer;

    // TIMER0
    if(TMR0IF)
    {
        debounce_timer++;
        if (debounce_timer == 0)
            updateButtonReadings();
        leddriver_writeNextRowToMatrix();   // write next row to LED-matrix
        TMR0 = 0x80;
        TMR0IF = 0;                         // Clear Interrupt Flag
    }
    // INTERRUPT PIN INT2 (RTC signals every 1 second)
    else if(INT2IF)
    {
        rtc_updated = 1;
        INT2IF = 0;     // Clear Interrupt Flag
    }
    else
    {
        /* Unhandled interrupts */
    }
}