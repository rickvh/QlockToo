/* 
 * File:   characters.h
 * Author: Rick
 *
 * Created on 28 april 2013, 22:11
 */

#ifndef CHARACTERS_H
#define	CHARACTERS_H

extern const char numbers[][7];
extern const char letters[][5];
extern const char symbols[][5];

#endif	/* CHARACTERS_H */

